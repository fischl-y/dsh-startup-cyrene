# 昔涟余额挂件 2.0（无动画）

> 中文原文备份，英文版见 `README.md`。

和 `../animated/` 内容几乎一样，唯独**没有**打开客户端时的全屏加载动画——打开就是正常界面，
加载成功 0.7 秒后播放「昔涟的问候」语音。

## 与带动画版的差别

| 项目 | animated | 本版 |
|---|---|---|
| 加载屏幕 | 全屏播 `loading.mp4`（13.9 秒） | 无 |
| 问候时机 | 动画淡出后 2.5 秒 | 页面加载后 0.7 秒 |
| 挂件本体 | 完全相同 | 完全相同 |
| 包名 | `dsh-cyrene-whale-widget` | `dsh-cyrene-whale-widget-noanim` |

## 共同内容（两版一致）

- 形象：昔涟（610×610 透明底、底部对齐）
- 台词：25 句，字号 6/7/8/9，首次点击余额面板
- 内置泡泡图：昔涟眨眼抱爱心（`rua.gif` / `bubble-petpet.gif` / `bubble-money1.gif` 都已替换，透明底）
- 问候：`assets/greeting.wav`（3.58 秒）
- 其余（音效、吸附、记账、泡泡编辑器）沿用 `dsh-whale-widget` 0.4.2

## 安装

先停用带动画版（`dsh-cyrene-whale-widget`），再 `install_bundle` 本目录。
两版共用 `/dsh-whale/*` 路由与 `$DSH_HOME/.dshw-*.json`，同一时间只能启用一个。

## 改东西

- 台词：右键挂件 → 泡泡设置；或 `assets/whale-widget.js` 的 `BUBBLE_DEFAULT_ITEMS`；批量用 `tools/set-lines.py`
- 字号：`tools/resize-lines.py`
- 问候语音：替换 `assets/greeting.wav`，刷新生效
