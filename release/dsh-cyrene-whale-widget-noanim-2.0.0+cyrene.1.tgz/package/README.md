# Cyrene Balance Widget 2.0 (No Animation)

Identical to the animated build (`dsh-cyrene-whale-widget`) except it has **no** splash screen —
the UI opens immediately and "Cyrene's Greeting" plays 0.7 s after load.

## Differences from the animated build

| Item | animated | this build |
|---|---|---|
| Splash screen | full-screen `loading.mp4` (13.9 s) | none |
| Greeting timing | 2.5 s after the animation fades out | 0.7 s after page load |
| Widget itself | identical | identical |
| Package name | `dsh-cyrene-whale-widget` | `dsh-cyrene-whale-widget-noanim` |

## Shared content (both builds)

- Character: Cyrene (610×610, transparent, bottom-aligned)
- Lines: 25 quotes, font sizes 6/7/8/9; the first click shows the balance panel
- Built-in bubble images: Cyrene winking with a heart (`rua.gif` / `bubble-petpet.gif` / `bubble-money1.gif`, all replaced, transparent)
- Greeting: `assets/greeting.wav` (3.58 s)
- Everything else (sound effects, snapping, accounting, bubble editor) comes from `dsh-whale-widget` 0.4.2

## Install

Disable the animated build (`dsh-cyrene-whale-widget`) first, then `install_bundle` this directory.
Both share the `/dsh-whale/*` routes and `$DSH_HOME/.dshw-*.json`, so only one can be enabled at a time.

## Customising

- **Lines**: right-click the widget → bubble settings; or `BUBBLE_DEFAULT_ITEMS` in `assets/whale-widget.js`; batch via `tools/set-lines.py`
- **Font size**: `tools/resize-lines.py`
- **Greeting audio**: replace `assets/greeting.wav`, refresh to apply
